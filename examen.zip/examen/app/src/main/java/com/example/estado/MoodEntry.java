package com.example.estado; // Paquete corregido

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.List;

@Entity(tableName = "mood_entries")
@TypeConverters({Converters.class})
public class MoodEntry {

    @PrimaryKey(autoGenerate = true)
    public int id;

    // Usamos System.currentTimeMillis()
    public long timestamp;

    // 1 = terrible, 2 = mal, 3 = normal, 4 = bien, 5 = genial
    public int moodRating;

    public String notes;

    // Lista de actividades, ej: ["work", "exercise"]
    public List<String> activities;

    // Constructor
    public MoodEntry(long timestamp, int moodRating, String notes, List<String> activities) {
        this.timestamp = timestamp;
        this.moodRating = moodRating;
        this.notes = notes;
        this.activities = activities;
    }
}
