package com.example.estado; // Paquete corregido

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.estado.db.AppDatabase; // Import corregido
import com.example.estado.db.MoodDao; // Import corregido
import com.example.estado.db.MoodEntry; // Import corregido

import java.util.List;

public class MoodViewModel extends AndroidViewModel {

    private MoodDao moodDao;
    private LiveData<List<MoodEntry>> allEntries;

    public MoodViewModel(Application application) {
        super(application);
        AppDatabase db = AppDatabase.getDatabase(application);
        moodDao = db.moodDao();
        allEntries = moodDao.getAllEntries();
    }

    // El Fragmento observará esto para actualizar la UI
    public LiveData<List<MoodEntry>> getAllEntries() {
        return allEntries;
    }

    // El Fragmento llamará a esto para guardar una nueva entrada
    public void insert(MoodEntry moodEntry) {
        // Usamos un hilo en segundo plano para no bloquear la UI
        AppDatabase.databaseWriteExecutor.execute(() -> {
            moodDao.insert(moodEntry);
        });
    }
}
