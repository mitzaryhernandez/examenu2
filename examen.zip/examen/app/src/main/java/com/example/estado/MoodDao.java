package com.example.estado.db; // Paquete corregido

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MoodDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(MoodEntry moodEntry);

    // Obtiene todas las entradas ordenadas por fecha (más nuevas primero)
    // LiveData notificará automáticamente a la UI cuando los datos cambien
    @Query("SELECT * FROM mood_entries ORDER BY timestamp DESC")
    LiveData<List<MoodEntry>> getAllEntries();

    // Query para buscar por rango de fechas (útil para el calendario)
    @Query("SELECT * FROM mood_entries WHERE timestamp BETWEEN :startDate AND :endDate")
    LiveData<List<MoodEntry>> getEntriesForDateRange(long startDate, long endDate);
}
