package com.example.estado.ui.stats; // Paquete corregido

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.estado.R; // Import corregido
import com.example.estado.databinding.FragmentStatsBinding; // Import corregido
import com.example.estado.db.MoodEntry; // Import corregido
import com.example.estado.ui.MoodViewModel; // Import corregido
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class StatsFragment extends Fragment {

    private FragmentStatsBinding binding;
    private MoodViewModel moodViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        moodViewModel = new ViewModelProvider(requireActivity()).get(MoodViewModel.class);
        binding = FragmentStatsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Observamos todas las entradas de la base de datos
        moodViewModel.getAllEntries().observe(getViewLifecycleOwner(), entries -> {
            if (entries != null && !entries.isEmpty()) {
                // Si hay datos, calculamos los patrones y actualizamos las gráficas
                calculateActivityPatterns(entries);
                setupMoodOverTimeChart(entries);
            } else {
                // Si no hay datos, mostramos un mensaje
                binding.textActivityPatterns.setText(R.string.stats_no_data);
                binding.chartMoodOverTime.clear();
            }
        });

        return root;
    }

    /**
     * Esta es la función CLAVE para "buscar patrones".
     * Calcula el promedio de ánimo para cada actividad registrada.
     */
    private void calculateActivityPatterns(List<MoodEntry> entries) {
        // Usamos un Map para guardar la lista de calificaciones por cada actividad
        // Ej: "Trabajo" -> [3, 2, 4], "Ejercicio" -> [5, 4, 5]
        Map<String, List<Integer>> activityMoodMap = new HashMap<>();

        for (MoodEntry entry : entries) {
            if (entry.activities == null) continue;

            for (String activity : entry.activities) {
                // Si la actividad no está en el mapa, la añadimos
                if (!activityMoodMap.containsKey(activity)) {
                    activityMoodMap.put(activity, new ArrayList<>());
                }
                // Añadimos la calificación de esta entrada a la lista de la actividad
                activityMoodMap.get(activity).add(entry.moodRating);
            }
        }

        // Ahora, calculamos el promedio para cada actividad
        StringBuilder patternsReport = new StringBuilder();

        if (activityMoodMap.isEmpty()) {
            binding.textActivityPatterns.setText(R.string.stats_no_data);
            return;
        }

        for (Map.Entry<String, List<Integer>> pair : activityMoodMap.entrySet()) {
            String activity = pair.getKey();
            List<Integer> ratings = pair.getValue();

            if (ratings.isEmpty()) continue;

            double sum = 0;
            for (int rating : ratings) {
                sum += rating;
            }
            double average = sum / ratings.size();
            int count = ratings.size();

            // Creamos un string formateado y lo añadimos al reporte
            String patternString = getString(R.string.stats_pattern_format, activity, average, count);
            patternsReport.append(patternString).append("\n\n");
        }

        binding.textActivityPatterns.setText(patternsReport.toString());
    }

    /**
     * Configura la gráfica de línea para mostrar el ánimo a lo largo del tiempo.
     */
    private void setupMoodOverTimeChart(List<MoodEntry> entries) {
        LineChart chart = binding.chartMoodOverTime;

        // Invertimos la lista para que la gráfica vaya de izquierda (antiguo) a derecha (nuevo)
        List<MoodEntry> reversedEntries = new ArrayList<>(entries);
        Collections.reverse(reversedEntries);

        ArrayList<Entry> chartEntries = new ArrayList<>();
        final ArrayList<String> xLabels = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM", Locale.getDefault());

        for (int i = 0; i < reversedEntries.size(); i++) {
            MoodEntry entry = reversedEntries.get(i);
            // (x, y) -> (índice, calificación)
            chartEntries.add(new Entry(i, entry.moodRating));
            // Guardamos la etiqueta de fecha para el eje X
            xLabels.add(sdf.format(new Date(entry.timestamp)));
        }

        LineDataSet dataSet = new LineDataSet(chartEntries, "Calificación de Ánimo");
        dataSet.setColor(Color.BLUE);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setLineWidth(2f);
        dataSet.setCircleRadius(4f);
        dataSet.setDrawCircleHole(false);

        LineData lineData = new LineData(dataSet);
        chart.setData(lineData);

        // Formatear el eje X para mostrar fechas en lugar de números
        XAxis xAxis = chart.getXAxis();
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int index = (int) value;
                if (index >= 0 && index < xLabels.size()) {
                    return xLabels.get(index);
                }
                return "";
            }
        });
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f); // Mostrar todas las etiquetas
        xAxis.setLabelRotationAngle(-45);

        chart.getDescription().setEnabled(false); // Sin descripción
        chart.getAxisRight().setEnabled(false); // Sin eje Y derecho
        chart.getAxisLeft().setAxisMaximum(5.5f); // Máximo 5
        chart.getAxisLeft().setAxisMinimum(0.5f); // Mínimo 1
        chart.getAxisLeft().setGranularity(1f);
        chart.invalidate(); // Refrescar la gráfica
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
