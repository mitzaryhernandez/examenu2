package com.example.estado; // Paquete corregido

import androidx.room.TypeConverter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Converters {

    // Convierte una Lista de Strings a un solo String, ej: "work,exercise,social"
    @TypeConverter
    public String fromActivityList(List<String> activities) {
        if (activities == null || activities.isEmpty()) {
            return "";
        }
        // Usamos un delimitador que sea poco probable en una actividad
        return String.join(";;", activities);
    }

    // Convierte un String de vuelta a una Lista de Strings
    @TypeConverter
    public List<String> toActivityList(String data) {
        if (data == null || data.isEmpty()) {
            return java.util.Collections.emptyList();
        }
        return Arrays.asList(data.split(";;"));
    }
}
