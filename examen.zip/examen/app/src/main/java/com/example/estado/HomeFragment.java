package com.example.estado; // Paquete corregido

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.estado.R; // Import corregido
import com.example.estado.databinding.FragmentHomeBinding; // Import corregido
import com.example.estado.db.MoodEntry; // Import corregido
import com.example.estado.ui.MoodViewModel; // Import corregido
import com.google.android.material.chip.Chip;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private MoodViewModel moodViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        // Obtenemos el ViewModel
        // Asegúrate que el ViewModel se obtiene del scope correcto (aquí usamos 'this' - el fragmento)
        moodViewModel = new ViewModelProvider(requireActivity()).get(MoodViewModel.class);

        // Usamos ViewBinding para acceder fácilmente a las vistas
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Configuramos el listener del botón de guardar
        binding.buttonSave.setOnClickListener(v -> saveMoodEntry());

        return root;
    }

    private void saveMoodEntry() {
        // 1. Obtener la calificación
        int rating = (int) binding.moodRatingBar.getRating();
        if (rating == 0) {
            Toast.makeText(getContext(), "Por favor, selecciona una calificación", Toast.LENGTH_SHORT).show();
            return;
        }

        // 2. Obtener las actividades seleccionadas
        List<String> selectedActivities = new ArrayList<>();
        for (int i = 0; i < binding.chipGroupActivities.getChildCount(); i++) {
            Chip chip = (Chip) binding.chipGroupActivities.getChildAt(i);
            if (chip.isChecked()) {
                selectedActivities.add(chip.getText().toString());
            }
        }

        // 3. Obtener las notas
        String notes = binding.editTextNotes.getText().toString();

        // 4. Obtener la fecha/hora actual
        long timestamp = System.currentTimeMillis();

        // 5. Crear el objeto MoodEntry
        MoodEntry newEntry = new MoodEntry(timestamp, rating, notes, selectedActivities);

        // 6. Insertar en la base de datos a través del ViewModel
        moodViewModel.insert(newEntry);

        // 7. Mostrar confirmación y limpiar
        Toast.makeText(getContext(), R.string.entry_saved_success, Toast.LENGTH_SHORT).show();
        resetFields();
    }

    private void resetFields() {
        binding.moodRatingBar.setRating(0);
        binding.editTextNotes.setText("");
        for (int i = 0; i < binding.chipGroupActivities.getChildCount(); i++) {
            Chip chip = (Chip) binding.chipGroupActivities.getChildAt(i);
            chip.setChecked(false);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
