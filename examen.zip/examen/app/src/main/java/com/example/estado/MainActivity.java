package com.example.estado; // Asegúrate que el paquete sea 'db' si lo pusiste en un subdirectorio

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// ESTE ES EL CONTENIDO CORRECTO PARA AppDatabase.java
// NO DEBE HABER NADA DE 'MainActivity' AQUÍ.

@Database(entities = {com.example.estado.db.MoodEntry.class}, version = 1, exportSchema = false)
@TypeConverters({com.example.estado.db.Converters.class})
abstract class AppDatabase extends RoomDatabase {

    public abstract com.example.estado.db.MoodDao moodDao();

    private static volatile AppDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "mood_database")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}

