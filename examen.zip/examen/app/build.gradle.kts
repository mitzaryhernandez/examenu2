plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.estado"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.estado"
        minSdk = 27
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    // Habilita viewBinding (necesario para los fragmentos)
    buildFeatures {
        viewBinding = true
    }
}

dependencies {

    // Dependencias de tu catálogo (libs)
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    implementation(libs.room.common.jvm)
    implementation(libs.room.runtime)
    implementation(libs.navigation.runtime)
    implementation(libs.navigation.fragment)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
    annotationProcessor(libs.room.compiler)

    // --- Dependencias que faltaban ---
    // (Asegúrate de que no estén ya en tu archivo libs.versions.toml)

    // ViewModel y LiveData (Arquitectura)
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")

    // Navigation UI (Necesario para BottomNavigationView)
    implementation("androidx.navigation:navigation-ui:2.7.7")

    // Para las gráficas (Patrones de estado de ánimo)
    implementation("com.github.PhilJay:MPAndroidChart:v3.1.0")

}

