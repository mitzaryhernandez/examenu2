// En tu archivo settings.gradle.kts (en la raíz del proyecto)

pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()

        // --- ¡AÑADE ESTA LÍNEA AQUÍ DENTRO! ---
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "estado"
include(":app")